package telas;
public class Login {

    public static void main(String[] args){
        UILogin login = new UILogin();
        login.setVisible(true);
    }
}